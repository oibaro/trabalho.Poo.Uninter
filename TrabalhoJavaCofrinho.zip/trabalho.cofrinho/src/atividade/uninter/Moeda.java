package atividade.uninter;

public abstract class Moeda { // Atributo para armazenar o valor da moeda
	
	protected double valor;
	
	public abstract void info();
	public abstract double converter();

}
